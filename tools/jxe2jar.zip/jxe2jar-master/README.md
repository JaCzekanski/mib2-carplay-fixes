# JXE2JAR

> [!NOTE]
> This fork has been modernized by @kurtmorris for use with Python3!

Tool for reverse conversion from Intel JXE format to Oracle JAR.
Detailed info in doc/jxe2jar.pdf.

## Dependencies
bitstring

## Using
python3 JXE2JAR.py input.jxe output.jar

## Thanks to @Black2Fan
